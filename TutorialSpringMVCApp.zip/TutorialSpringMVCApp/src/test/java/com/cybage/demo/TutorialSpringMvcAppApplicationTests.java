package com.cybage.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TutorialSpringMvcAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
