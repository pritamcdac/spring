package com.cybage.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cybage.model.Tutorial;

@Service
public class TutorialService {
	private List<Tutorial> tutorialList = new ArrayList<>();
	
	public TutorialService() {
		tutorialList.add(new Tutorial(1, "Java", "Java Tutorial"));
		tutorialList.add(new Tutorial(2, "C", "C Tutorial"));
		tutorialList.add(new Tutorial(3, "C++", "C++ Tutorial"));
		tutorialList.add(new Tutorial(4, ".net", ".net Tutorial"));
		tutorialList.add(new Tutorial(5, "Database", "Database Tutorial"));
	}
}
